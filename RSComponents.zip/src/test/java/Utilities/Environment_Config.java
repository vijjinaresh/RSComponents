package Utilities;

public class Environment_Config {

    protected static String URL = "https://uk.rs-online.com/web/";

    public static String getURL()
    {
        return URL;
    }

}
